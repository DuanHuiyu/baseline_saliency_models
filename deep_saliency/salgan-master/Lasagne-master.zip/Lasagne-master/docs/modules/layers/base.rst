Layer base classes
------------------

.. automodule:: lasagne.layers.base

.. currentmodule:: lasagne.layers

.. autoclass:: Layer
   :members:

.. autoclass:: MergeLayer
    :members:

