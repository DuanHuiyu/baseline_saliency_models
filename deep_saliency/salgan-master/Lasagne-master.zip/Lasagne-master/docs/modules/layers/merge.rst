Merge layers
------------

.. automodule:: lasagne.layers.merge

.. currentmodule:: lasagne.layers

.. autoclass:: ConcatLayer
    :members:

.. autoclass:: concat

.. autoclass:: ElemwiseMergeLayer
    :members:

.. autoclass:: ElemwiseSumLayer
    :members:

