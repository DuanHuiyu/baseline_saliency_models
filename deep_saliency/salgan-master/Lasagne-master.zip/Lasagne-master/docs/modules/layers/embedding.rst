Embedding layers
----------------

.. automodule:: lasagne.layers.embedding

.. currentmodule:: lasagne.layers

.. autoclass:: EmbeddingLayer
    :members:

